package com.example.springMvcExample.controller;

import java.awt.Color;
import javax.swing.JFrame;
import javax.swing.SwingUtilities;
import javax.swing.WindowConstants;
import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartPanel;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.plot.XYPlot;
import org.jfree.data.time.Day;
import org.jfree.data.time.TimeSeries;
import org.jfree.data.time.TimeSeriesCollection;
import org.jfree.data.xy.XYDataset;

public class ChartController extends JFrame {

	private static final long serialVersionUID = 1L;

	public ChartController(String title) {
		super(title);
		// Create dataset
		XYDataset dataset = createDataset();
		// Create chart
		JFreeChart chart = ChartFactory.createTimeSeriesChart("Stock Price Chart", "Date", "Current Price", dataset,
				rootPaneCheckingEnabled, rootPaneCheckingEnabled, rootPaneCheckingEnabled);

		XYPlot plot = (XYPlot) chart.getPlot();
		plot.setBackgroundPaint(new Color(222, 243, 255));

		ChartPanel panel = new ChartPanel(chart);
		setContentPane(panel);
	}

	private XYDataset createDataset() {
		TimeSeriesCollection dataset = new TimeSeriesCollection();

		TimeSeries series1 = new TimeSeries("Series1");
		series1.add(new Day(1, 1, 2019), 4345);
		series1.add(new Day(4, 1, 2019), 75000);
		series1.add(new Day(20, 5, 2019), 45032);
		series1.add(new Day(12, 6, 2019), 30041);
		series1.add(new Day(15, 8, 2019), 7023);
		series1.add(new Day(12, 7, 2019), 45397);
		series1.add(new Day(19, 10, 2019), 6450);
		series1.add(new Day(21, 10, 2019), 9745);
		series1.add(new Day(25, 11, 2019), 89000);
		series1.add(new Day(29, 11, 2019), 25002);
		dataset.addSeries(series1);

		return dataset;
	}

	public static void main(String[] args) {
		SwingUtilities.invokeLater(() -> {
			ChartController example = new ChartController("Stock Chart");
			example.setSize(800, 400);
			example.setLocationRelativeTo(null);
			example.setVisible(true);
			example.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
		});
	}
}
