package com.example.springMvcExample.controller;

import java.math.BigDecimal;
import java.sql.SQLException;
import java.util.Date;
import java.util.List;

import javax.print.attribute.standard.DateTimeAtCompleted;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import javax.validation.Valid;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.example.springMvcExample.exception.ApplicationException;
import com.example.springMvcExample.model.Company;
import com.example.springMvcExample.model.Sector;
import com.example.springMvcExample.model.StockPrice;
import com.example.springMvcExample.service.CompanyService;
import com.example.springMvcExample.service.StockPriceService;

@Controller
public class StockPriceControllerImpl implements StockPriceController {

	@Autowired
	private StockPriceService stockPriceService;

	@Autowired
	private CompanyService companyService;

	public static final Logger LOGGER = Logger.getLogger("springMvcExample");

	@RequestMapping(path = "/stockPriceList")
	public ModelAndView getStockList() throws ApplicationException {
		ModelAndView mv = new ModelAndView();
		mv.setViewName("stockPriceList");
		mv.addObject("stockPriceList", stockPriceService.getStockList());
		return mv;
	}

	@RequestMapping(path = "/registerStockPricePage", method = RequestMethod.GET)
	public ModelAndView registerStockPricePage(Model model) {

		ModelAndView mv = new ModelAndView();
		try {
			mv.setViewName("registerStockPrice");
			model.addAttribute("stockPriceRegister", new StockPrice());
		} catch (Exception e) {
			// TODO Auto-generated catch block
			LOGGER.error(e.getMessage());
			e.printStackTrace();
		}
		return mv;
	}

	@RequestMapping(value = "/registerStockPrice", method = RequestMethod.POST)
	public ModelAndView registerStockPrice(@Valid @ModelAttribute("stockPriceRegister") StockPrice stockPrice,
			BindingResult result, HttpServletRequest request, HttpSession session, ModelMap map) {
		ModelAndView mav = null;
		try {
			if (result.hasErrors()) {

				map.addAttribute("stockPriceRegister", stockPrice);
				mav = new ModelAndView("registerStockPrice");

			}

			else {
				map.addAttribute("stockPriceRegister", stockPrice);
				stockPriceService.insertStock(stockPrice);
				mav = new ModelAndView("stockPriceList");
				mav.addObject("stockPriceList", stockPriceService.getStockList());

			}
		} catch (ApplicationException e) {
			// TODO Auto-generated catch block
			LOGGER.error(e.getMessage());
			e.printStackTrace();
		}
		return mav;

	}

	@RequestMapping(path = "/updateStockPricePage", method = RequestMethod.GET)
	public ModelAndView update(Model model) {
		ModelAndView mv = new ModelAndView();
		try {
			mv.setViewName("updateStockPrice");
			model.addAttribute("updateStockPrice", new StockPrice());
		} catch (Exception e) {
			// TODO Auto-generated catch block
			LOGGER.error(e.getMessage());
			e.printStackTrace();
		}

		return mv;
	}

	@RequestMapping(value = "/updateStockPrice", method = RequestMethod.POST)
	public ModelAndView updateCompany(@Valid @ModelAttribute("updateStockPrice") StockPrice stockPrice,
			BindingResult result, HttpServletRequest request, HttpSession session, ModelMap map, Model model) {
		ModelAndView mav = null;
		try {
			if (result.hasErrors()) {
				System.out.println("errors");
				System.out.println(result.getAllErrors());
				ModelAndView mv = new ModelAndView();
				mv.setViewName("updateStockPrice");

				return mv;
			} else {

				map.addAttribute("updateStockPrice", stockPrice);
				stockPriceService.updateStockPrice(stockPrice);
				mav = new ModelAndView("stockPriceList");
				mav.addObject("stockPriceList", stockPriceService.getStockList());

			}
		} catch (ApplicationException e) {
			LOGGER.error(e.getMessage());
			e.printStackTrace();
		}
		return mav;
	}

	@Override
	public void insertStock(StockPrice stockPrice) throws ApplicationException {

		try {
			stockPriceService.insertStock(stockPrice);
			;
		} catch (ApplicationException e) {
			LOGGER.error(e.getMessage());
			e.printStackTrace();
		}

	}

	@Override
	public boolean updateStockPrice(StockPrice stockPrice) throws ApplicationException {
		// TODO Auto-generated method stub
		boolean flag = false;
		try {
			flag = stockPriceService.updateStockPrice(stockPrice);
		} catch (ApplicationException e) {
			LOGGER.error(e.getMessage());
			e.printStackTrace();
		}
		return flag;
	}

}
