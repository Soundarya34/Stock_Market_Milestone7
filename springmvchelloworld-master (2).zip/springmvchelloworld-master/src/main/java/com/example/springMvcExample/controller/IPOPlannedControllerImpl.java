package com.example.springMvcExample.controller;

import java.sql.SQLException;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import javax.validation.Valid;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.example.springMvcExample.exception.ApplicationException;
import com.example.springMvcExample.model.Company;
import com.example.springMvcExample.model.IPOPlanned;
import com.example.springMvcExample.model.StockExchange;
import com.example.springMvcExample.service.CompanyService;
import com.example.springMvcExample.service.IPOPlannedService;
import com.example.springMvcExample.service.StockExchangeService;

@Controller
public class IPOPlannedControllerImpl implements IPOPlannedController {

	@Autowired
	private IPOPlannedService ipoPlannedService;

	@Autowired
	private CompanyService companyService;

	@Autowired
	private StockExchangeService stockExchangeService;

	public static final Logger LOGGER = Logger.getLogger("springMvcExample");

	@Override
	public boolean insertIPO(IPOPlanned ipoPlanned) {
		// TODO Auto-generated method stub
		boolean flag = false;
		try {
			flag = ipoPlannedService.insertIPO(ipoPlanned);
		} catch (ApplicationException e) {
			// TODO Auto-generated catch block
			LOGGER.error(e.getMessage());
			e.printStackTrace();
		}
		return flag;
	}

	@RequestMapping(path = "/registerIPOPage", method = RequestMethod.GET)
	public ModelAndView registerIPOPage(Model model) throws Exception {
		ModelAndView mv = new ModelAndView();
		try {
			List<Company> companyList = companyService.getCompanyList();
			List<StockExchange> stockExchangeList = stockExchangeService.getStockExchangeList();
			mv.setViewName("registerIPO");
			model.addAttribute("ipoPlanned", new IPOPlanned());
			model.addAttribute("companyList", companyList);
			model.addAttribute("stockExchangeList", stockExchangeList);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			LOGGER.error(e.getMessage());
			e.printStackTrace();
		}
		return mv;
	}

	@RequestMapping(value = "/registerIPO", method = RequestMethod.GET)
	public ModelAndView registerSector(@Valid @ModelAttribute("ipoPlanned") IPOPlanned ipoPlanned, BindingResult result,
			HttpServletRequest request, HttpSession session, ModelMap map) throws Exception {
		ModelAndView mav = null;
		try {
			if (result.hasErrors()) {
				List<Company> companyList = companyService.getCompanyList();
				List<StockExchange> stockExchangeList = stockExchangeService.getStockExchangeList();
				map.addAttribute("companyList", companyList);
				map.addAttribute("stockExchangeList", stockExchangeList);
				mav = new ModelAndView("registerIPO");

			}

			else {
				map.addAttribute("ipoPlanned", ipoPlanned);
				ipoPlannedService.insertIPO(ipoPlanned);
				mav = new ModelAndView("ipoPlannedList");
				mav.addObject("ipoPlannedList", ipoPlannedService.getIPOPlannedList());

			}
		} catch (ApplicationException e) {
			// TODO Auto-generated catch block
			LOGGER.error(e.getMessage());
			e.printStackTrace();
		}
		return mav;

	}

	@RequestMapping(path = "/ipoPlannedList")
	public ModelAndView getIPOPlannedList() {
		ModelAndView mv = new ModelAndView();
		try {
			mv.setViewName("ipoPlannedList");
			mv.addObject("ipoPlannedList", ipoPlannedService.getIPOPlannedList());
		} catch (ApplicationException e) {
			// TODO Auto-generated catch block
			LOGGER.error(e.getMessage());
			e.printStackTrace();
		}

		return mv;
	}

	@RequestMapping(path = "/updateIpoPage", method = RequestMethod.GET)
	public ModelAndView update(Model model) throws Exception {
		ModelAndView mv = new ModelAndView();
		try {
			mv.setViewName("updateIPO");
			model.addAttribute("updateIPO", new IPOPlanned());
			List<Company> companyList = companyService.getCompanyList();
			List<StockExchange> stockExchangeList = stockExchangeService.getStockExchangeList();
			model.addAttribute("companyList", companyList);
			model.addAttribute("stockExchangeList", stockExchangeList);
		} catch (ApplicationException e) {
			// TODO Auto-generated catch block
			LOGGER.error(e.getMessage());
			e.printStackTrace();
		}
		return mv;
	}

	@RequestMapping(value = "/updateIPO", method = RequestMethod.GET)
	public ModelAndView updateIpo(@Valid @ModelAttribute("updateIpo") IPOPlanned ipoPlanned, BindingResult result,
			HttpServletRequest request, HttpSession session, ModelMap map, Model model) throws SQLException {
		ModelAndView mav = new ModelAndView();
		try {
			if (result.hasErrors()) {
				System.out.println("errors");
				System.out.println(result.getAllErrors());

				mav.setViewName("updateIPO");

			} else {

				map.addAttribute("updateIpo", ipoPlanned);
				ipoPlannedService.updateIpo(ipoPlanned);
				mav = new ModelAndView("ipoPlannedList");
				mav.addObject("ipoPlannedList", ipoPlannedService.getIPOPlannedList());

			}
		} catch (ApplicationException e) {
			// TODO Auto-generated catch block
			LOGGER.error(e.getMessage());
			e.printStackTrace();
		}
		return mav;
	}

	@Override
	public boolean updateIpo(IPOPlanned ipoPlanned) throws SQLException {
		// TODO Auto-generated method stub
		boolean flag = false;
		try {
			flag = ipoPlannedService.updateIpo(ipoPlanned);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			LOGGER.error(e.getMessage());
			e.printStackTrace();
		}
		return flag;
	}

}
