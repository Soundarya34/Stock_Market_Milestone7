package com.example.springMvcExample.service;

import java.sql.SQLException;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.springMvcExample.dao.SectorDao;
import com.example.springMvcExample.exception.ApplicationException;
import com.example.springMvcExample.model.Sector;

@Service
public class SectorServiceImpl implements SectorService {

	@Autowired
	private SectorDao sectorDao;

	@Override
	public boolean insertSector(Sector sector) throws ApplicationException {
		// TODO Auto-generated method stub
		boolean flag = false;
		try {
			sectorDao.save(sector);
			flag = true;
		} catch (Exception e) {
			throw new ApplicationException(e.getMessage());
		}

		return flag;
	}

	@Override
	public List<Sector> getSectorList() throws ApplicationException {
		// TODO Auto-generated method stub
		return sectorDao.findAll();
	}

}
