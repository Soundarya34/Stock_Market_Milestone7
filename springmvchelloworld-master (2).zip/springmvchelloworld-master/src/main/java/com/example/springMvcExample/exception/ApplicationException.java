package com.example.springMvcExample.exception;

public class ApplicationException extends Exception{

	String exceptionerror;

	public ApplicationException(String exceptionerror) {
		this.exceptionerror = exceptionerror;
	}

	@Override
	public String toString() {
		return "There is a problem due to "+exceptionerror;
	}
	
	
	
	
}
