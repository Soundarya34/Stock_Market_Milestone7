package com.example.springMvcExample.service;

import java.sql.SQLException;
import java.util.List;

import javax.validation.Valid;

import com.example.springMvcExample.exception.ApplicationException;
import com.example.springMvcExample.model.IPOPlanned;


public interface IPOPlannedService {

public boolean insertIPO(IPOPlanned ipoPlanned ) throws  ApplicationException;
	
	public List<IPOPlanned> getIPOPlannedList() throws ApplicationException;

	public boolean updateIpo(IPOPlanned ipoPlanned) throws ApplicationException;
	
	
}
