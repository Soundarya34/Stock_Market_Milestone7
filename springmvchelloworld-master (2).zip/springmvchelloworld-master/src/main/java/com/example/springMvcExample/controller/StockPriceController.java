package com.example.springMvcExample.controller;

import org.springframework.web.servlet.ModelAndView;
import com.example.springMvcExample.exception.ApplicationException;

import com.example.springMvcExample.model.StockPrice;

public interface StockPriceController {
	public ModelAndView getStockList() throws ApplicationException;

	public void insertStock(StockPrice stockPrice) throws ApplicationException;

	public boolean updateStockPrice(StockPrice stockPrice) throws ApplicationException;

}
