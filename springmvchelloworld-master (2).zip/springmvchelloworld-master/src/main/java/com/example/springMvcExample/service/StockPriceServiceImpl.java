package com.example.springMvcExample.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.springMvcExample.dao.StockPriceDao;
import com.example.springMvcExample.exception.ApplicationException;
import com.example.springMvcExample.model.StockPrice;

@Service
public class StockPriceServiceImpl implements StockPriceService {

	@Autowired
	private StockPriceDao stockPriceDao;

	@Override
	public List<StockPrice> getStockList() throws ApplicationException {
		// TODO Auto-generated method stub
		return stockPriceDao.findAll();
	}

	@Override
	public void insertStock(StockPrice stockPrice) throws ApplicationException {

		try {
			stockPriceDao.save(stockPrice);
		} catch (Exception e) {
			throw new ApplicationException(e.getMessage());
		}

	}

	@Override
	public boolean updateStockPrice(StockPrice stockPrice) throws ApplicationException {
		// TODO Auto-generated method stub
		boolean flag = false;
		try {
			stockPriceDao.save(stockPrice);
			flag = true;
		} catch (Exception e) {
			throw new ApplicationException(e.getMessage());
		}
		return flag;

	}

}
