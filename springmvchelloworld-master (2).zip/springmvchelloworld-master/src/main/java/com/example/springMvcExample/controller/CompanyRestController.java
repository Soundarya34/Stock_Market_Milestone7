package com.example.springMvcExample.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

import com.example.springMvcExample.dao.CompanyDao;
import com.example.springMvcExample.model.Company;

@RestController
public class CompanyRestController {

	@Autowired
	CompanyDao companyDao;

	@GetMapping("/companyDisplay/{sectorId}")
	public List<Company> SectorList(@PathVariable("sectorId") Integer sectorId) {

		return companyDao.findBysectorId(sectorId);
	}

	@GetMapping(value = "/companyMatch/{letter}")
	public List<Company> findByCompany(@PathVariable String letter) {
		List<Company> companyList = companyDao.findBycompanyName(letter);
		return companyList;
	}

}  

