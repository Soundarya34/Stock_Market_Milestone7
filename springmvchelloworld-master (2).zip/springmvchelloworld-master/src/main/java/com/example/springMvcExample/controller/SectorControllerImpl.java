package com.example.springMvcExample.controller;

import java.sql.SQLException;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import javax.validation.Valid;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.example.springMvcExample.exception.ApplicationException;
import com.example.springMvcExample.model.Sector;

import com.example.springMvcExample.service.SectorService;

@Controller
public class SectorControllerImpl implements SectorController {

	@Autowired
	private SectorService sectorService;

	public static final Logger LOGGER = Logger.getLogger("springMvcExample");

	@Override
	public boolean insertSector(Sector sector) {
		boolean flag = false;
		try {
			flag = sectorService.insertSector(sector);
		} catch (ApplicationException e) {
			// TODO Auto-generated catch block
			LOGGER.error(e.getMessage());
			e.printStackTrace();
		}

		return flag;
	}

	@RequestMapping(path = "/registerSectorPage", method = RequestMethod.GET)
	public ModelAndView registerSectorPage(Model model) {
		ModelAndView mv = new ModelAndView();
		try {
			mv.setViewName("registerSector");
			model.addAttribute("sector", new Sector());
		} catch (Exception e) {
			// TODO Auto-generated catch block
			LOGGER.error(e.getMessage());
			e.printStackTrace();
		}

		return mv;
	}

	@RequestMapping(value = "/registerSector", method = RequestMethod.GET)
	public ModelAndView registerSector(@Valid @ModelAttribute("sector") Sector sector, BindingResult result,
			HttpServletRequest request, HttpSession session, ModelMap map) {
		ModelAndView mav = null;
		try {
			if (result.hasErrors()) {

				map.addAttribute("sector", sector);
				mav = new ModelAndView("registerSector");

			}

			else {
				map.addAttribute("sector", sector);
				sectorService.insertSector(sector);
				mav = new ModelAndView("sectorList");
				mav.addObject("sectorList", sectorService.getSectorList());

			}
		} catch (ApplicationException e) {
			
			LOGGER.error(e.getMessage());
			e.printStackTrace();
		}
		return mav;
	}

	@RequestMapping(path = "/sectorList")
	public ModelAndView getSectorList() throws ApplicationException {
		ModelAndView mv = new ModelAndView();
		mv.setViewName("sectorList");
		mv.addObject("sectorList", sectorService.getSectorList());
		return mv;
	}

}