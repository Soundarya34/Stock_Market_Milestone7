package com.example.springMvcExample.service;

import java.util.List;

import javax.validation.Valid;

import com.example.springMvcExample.exception.ApplicationException;
import com.example.springMvcExample.model.StockPrice;

public interface StockPriceService {

	public List<StockPrice> getStockList()  throws  ApplicationException;

	public void insertStock(StockPrice stockPrice)  throws  ApplicationException;

	public boolean updateStockPrice(StockPrice stockPrice)  throws  ApplicationException;

}
