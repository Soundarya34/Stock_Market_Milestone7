package com.example.springMvcExample.service;

import java.sql.SQLException;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.springMvcExample.dao.CompanyDao;
import com.example.springMvcExample.exception.ApplicationException;
import com.example.springMvcExample.model.Company;

@Service
public class CompanyServiceImpl implements CompanyService {

	@Autowired
	private CompanyDao companyDao;

	@Override
	public boolean insertCompany(Company company) throws ApplicationException {
		// TODO Auto-generated method stub
		boolean flag = false;
		try {
			companyDao.save(company);
			flag = true;
		} catch (Exception e) {
			throw new ApplicationException(e.getMessage());
		}

		return flag;
	}

	@Override
	public List<Company> getCompanyList() throws ApplicationException {
		// TODO Auto-generated method stub
		return companyDao.findAll();
	}

	@Override
	public boolean updateCompany(Company company) throws ApplicationException {
		// TODO Auto-generated method stub
		boolean flag = false;
		try {
			companyDao.save(company);
			flag = true;
		} catch (Exception e) {
			throw new ApplicationException(e.getMessage());
		}

		return flag;
	}

}
