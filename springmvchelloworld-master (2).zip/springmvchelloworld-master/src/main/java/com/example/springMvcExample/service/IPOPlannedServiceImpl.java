package com.example.springMvcExample.service;

import java.sql.SQLException;
import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.springMvcExample.dao.IPOPlannedDao;
import com.example.springMvcExample.exception.ApplicationException;
import com.example.springMvcExample.model.IPOPlanned;

@Service
public class IPOPlannedServiceImpl implements IPOPlannedService {

	@Autowired
	private IPOPlannedDao ipoPlannedDao;

	@Override
	public boolean insertIPO(IPOPlanned ipoPlanned) throws ApplicationException {
		// TODO Auto-generated method stub
		boolean flag = false;
		try {
			ipoPlannedDao.save(ipoPlanned);
			flag = true;
		} catch (Exception e) {
			throw new ApplicationException(e.getMessage());
		}
		return flag;
	}

	@Override
	public List<IPOPlanned> getIPOPlannedList() throws ApplicationException {
		// TODO Auto-generated method stub
		return ipoPlannedDao.findAll();
	}

	@Override
	public boolean updateIpo(IPOPlanned ipoPlanned) throws ApplicationException {
		// TODO Auto-generated method stub
		boolean flag = false;
		try {
			ipoPlannedDao.save(ipoPlanned);
			flag = true;
		} catch (Exception e) {
			throw new ApplicationException(e.getMessage());
		}
		return flag;
	}
}
