package com.example.springMvcExample.controller;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.example.springMvcExample.exception.ApplicationException;
import com.example.springMvcExample.model.Company;
import com.example.springMvcExample.model.Sector;
import com.example.springMvcExample.model.User;
import com.example.springMvcExample.service.CompanyService;
import com.example.springMvcExample.service.SectorService;
import com.example.springMvcExample.service.UserService;
import org.apache.log4j.Logger;

@Controller
public class CompanyControllerImpl implements CompanyController {

	@Autowired
	private CompanyService companyService;

	@Autowired
	private SectorService sectorService;

	public static final Logger LOGGER = Logger.getLogger("springMvcExample");

	@Override
	public boolean insertCompany(Company company) {
		boolean flag = false;
		try {
			flag = companyService.insertCompany(company);
		} catch (ApplicationException e) {
			LOGGER.error(e.getMessage());
			e.printStackTrace();
		}
		return flag;

	}

	@RequestMapping(path = "/createCompanyPage", method = RequestMethod.GET)
	public ModelAndView registerCompany(Model model) {
		ModelAndView mv = new ModelAndView();
		List<Sector> sectorList;
		try {
			sectorList = sectorService.getSectorList();

			mv.setViewName("CreateCompany");
			model.addAttribute("company", new Company());
			model.addAttribute("sectorList", sectorList);
		} catch (ApplicationException e) {
			// TODO Auto-generated catch block
			LOGGER.error(e.getMessage());
			e.printStackTrace();
		}
		return mv;
	}

	@RequestMapping(value = "/registerCompany", method = RequestMethod.GET)
	public ModelAndView registerCompany(@Valid @ModelAttribute("company") Company company, BindingResult result,
			HttpServletRequest request, HttpSession session, ModelMap map) throws SQLException {
		ModelAndView mav = null;
		try {
			if (result.hasErrors()) {

				// map.addAttribute("company", company);
				List sectorList = (List) sectorService.getSectorList();
				map.addAttribute("sectorList", sectorList);
				mav = new ModelAndView("CreateCompany");

			} else {

				map.addAttribute("company", company);
				companyService.insertCompany(company);
				mav = new ModelAndView("companyList");
				mav.addObject("companyList", companyService.getCompanyList());

			}
		} catch (ApplicationException e) {
			LOGGER.error(e.getMessage());
			e.printStackTrace();
		}
		return mav;
	}

	@RequestMapping(path = "/companyList")
	public ModelAndView getCompanyList() {
		ModelAndView mv = new ModelAndView();
		try {

			mv.setViewName("companyList");
			mv.addObject("companyList", companyService.getCompanyList());
		} catch (ApplicationException e) {
			// TODO Auto-generated catch block
			LOGGER.error(e.getMessage());
			e.printStackTrace();
		}

		return mv;
	}

	@Override
	public boolean updateCompany(Company company) {
		// TODO Auto-generated method stub
		boolean flag = false;
		try {
			flag = companyService.updateCompany(company);
		} catch (ApplicationException e) {
			LOGGER.error(e.getMessage());
			e.printStackTrace();
		}
		return flag;
	}

	@RequestMapping(path = "/updateCompanyPage", method = RequestMethod.GET)
	public ModelAndView update(Model model) {
		ModelAndView mv = new ModelAndView();
		try {
			List sectorList = (List) sectorService.getSectorList();
			mv.setViewName("updateCompany");
			model.addAttribute("updateCompany", new Company());
			model.addAttribute("sectorList", sectorList);
		} catch (Exception e) {
			LOGGER.error(e.getMessage());
			e.printStackTrace();
		}

		return mv;
	}

	@RequestMapping(value = "/updateCompany", method = RequestMethod.POST)
	public ModelAndView updateCompany(@Valid @ModelAttribute("updateCompany") Company company, BindingResult result,
			HttpServletRequest request, HttpSession session, ModelMap map, Model model) {
		ModelAndView mav = new ModelAndView();
		try {
			if (result.hasErrors()) {
				System.out.println("errors");
				System.out.println(result.getAllErrors());
				mav.setViewName("updateCompany");
				model.addAttribute("updateCompany", new Company());

			} else {

				map.addAttribute("company", company);
				companyService.updateCompany(company);
				mav = new ModelAndView("companyList");
				mav.addObject("companyList", companyService.getCompanyList());

			}
		} catch (ApplicationException e) {
			LOGGER.error(e.getMessage());
			e.printStackTrace();
		}
		return mav;

	}

}