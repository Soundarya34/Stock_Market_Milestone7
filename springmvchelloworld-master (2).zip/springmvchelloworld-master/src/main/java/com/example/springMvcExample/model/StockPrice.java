package com.example.springMvcExample.model;

import java.util.Date;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;

import org.springframework.format.annotation.DateTimeFormat;

@Entity
@Table(name = "stock_price_details")
public class StockPrice {

	@Id // @GeneratedValue(strategy=GenerationType.AUTO)
	@Column(name = "stock_code")
	private int stockCode;

	// private List stockExchange;
	@Column(name = "current_price")
	private double currentPrice;

	@Column(name = "date")
	@NotNull(message = "DateShould not be Empty")
	@DateTimeFormat(pattern = "yyyy-MM-dd")
	private Date date;

	@Column(name = "time")
	@DateTimeFormat(pattern = "yyyy-MM-dd")
	@NotNull(message = "Time Should not be Empty")
	private Date time;

	@Column(name = "company_code")
	private Integer companyCode;

	public double getCurrentPrice() {
		return currentPrice;
	}

	@Column(name = "stock_price_name")
	private String stockName;

	public String getStockName() {
		return stockName;
	}

	public void setStockName(String stockName) {
		this.stockName = stockName;
	}

	public void setCurrentPrice(double currentPrice) {
		this.currentPrice = currentPrice;
	}

	public Date getDate() {
		return date;
	}

	public void setDate(Date date) {
		this.date = date;
	}

	public Date getTime() {
		return time;
	}

	public void setTime(Date time) {
		this.time = time;
	}

	public int getStockCode() {
		return stockCode;
	}

	public void setStockCode(int stockCode) {
		this.stockCode = stockCode;
	}

	public Integer getCompanyCode() {
		return companyCode;
	}

	public void setCompanyCode(Integer companyCode) {
		this.companyCode = companyCode;
	}

}
