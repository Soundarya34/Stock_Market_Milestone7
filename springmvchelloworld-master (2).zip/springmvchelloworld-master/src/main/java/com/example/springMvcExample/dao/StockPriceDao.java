package com.example.springMvcExample.dao;

import java.sql.Date;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.example.springMvcExample.model.StockPrice;

public interface StockPriceDao extends JpaRepository<StockPrice, Integer> {

	List<StockPrice> findBycompanyCode(Integer companyCode);

	@Query("Select s From StockPrice s where s.companyCode=:companyCode and s.date between :startDate and :endDate")
	List<StockPrice> findBydate(@Param("companyCode") Integer companyCode, @Param("startDate") Date startDate,
			@Param("endDate") Date endDate);

	@Query("Select s.currentPrice From StockPrice s where s.companyCode=:companyCode and s.date between :startDate and :endDate")
	List<Double> findBycompanyCode(@Param("companyCode") Integer companyCode, @Param("startDate") Date startDate,
			@Param("endDate") Date endDate);

}
