package com.example.springMvcExample.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.Email;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;

@Entity
@Table(name = "user")
public class User {

	@Id
	@Column(name = "user_id")
	private int userId;
	@Pattern(regexp = "^[A-Za-z]+$", message = "Username must have only alphabets")
	@NotEmpty(message = "Username is required")
	@Size(min = 1, max = 30, message = "Username must be between 1 to 20 characters")
	@Column(name = "username")
	private String username;

	@NotEmpty(message = "Password is required")
	@Size(min = 3, max = 30, message = "Password must be between 3 to 20 characters")
	@Column(name = "password")
	private String password;

	@NotEmpty(message = "User/Admin")
	@Column(name = "user_type")
	private String usertype;

	@Column(name = "email")
	@Email(message = "Give the required format")
	@NotEmpty(message = "Email is required")
	private String email;

	@Column(name = "mobile_number")
	@NotNull(message = "please enter mobile no")
	private long mobileNumber;

	@Column(name = "confirmed")
	@NotEmpty(message = "Confirmed is required")
	private String confirmed;

	public int getuserId() {
		return userId;
	}

	public void setuserId(int userId) {
		this.userId = userId;
	}

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getUsertype() {
		return usertype;
	}

	public void setUsertype(String usertype) {
		this.usertype = usertype;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public long getMobileNumber() {
		return mobileNumber;
	}

	public void setMobileNumber(long mobileNumber) {
		this.mobileNumber = mobileNumber;
	}

	public String getConfirmed() {
		return confirmed;
	}

	public void setConfirmed(String confirmed) {
		this.confirmed = confirmed;
	}

}
